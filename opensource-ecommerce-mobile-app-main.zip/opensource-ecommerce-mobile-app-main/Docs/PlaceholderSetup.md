# Splash and Logo Setup:--

**Splash screen-**

- Path - /Project/assets/lottie/
- Name - splash_screen.png


**Launcher icon-**

- Path - /Project/android/app/src/main/res/
- Name - ic_launcher-playstore.png


**Placeholder-**

- Path - /Project/assets/images/
- Name - placeholder.png

