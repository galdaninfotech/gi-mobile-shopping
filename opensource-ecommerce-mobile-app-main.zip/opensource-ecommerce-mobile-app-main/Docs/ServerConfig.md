# For Server setup of the application:

- Go to `Server_configuration.dart` file:

- Write your server credentials:

- var BASE_DOMAIN = "***********************"

- var HOST_NAME = BASE_DOMAIN

- var API_USER_NAME = "API_USER_NAME"

- var API_KEY = "API_KEY"
